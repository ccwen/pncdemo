jsonp_handler({
 "version": "1",
 "build": 218,
 "title": "漢譯佛典內容標誌系統 (YAP版)",
 "date": "2014-11-10T10:27:07.783Z",
 "description": "yinshun",
 "minruntime": "1.3",
 "baseurl": "http://ya.ksana.tw/yinshun/",
 "files": [
  "index.html",
  "build.js",
  "build.css",
  "jquery.js",
  "nodemain.js",
  "other.css",
  "jingkang.js",
  "react-with-addons.js",
  "ksana.js",
  "package.json"
 ],
 "filesizes": [
  538,
  548807,
  132618,
  277980,
  385,
  3730,
  9593,
  644338,
  835,
  402
 ],
 "filedates": [
  "2014-11-08T16:03:16.000Z",
  "2014-11-10T10:25:13.000Z",
  "2014-11-10T10:25:13.000Z",
  "2014-11-07T15:59:01.000Z",
  "2014-11-07T08:58:17.000Z",
  "2014-11-10T10:23:31.000Z",
  "2014-11-10T10:17:23.000Z",
  "2014-11-07T08:36:53.000Z",
  "2014-11-10T10:25:13.000Z",
  "2014-11-07T16:07:06.000Z"
 ]
})